
            function SEND_MASSAGE(){
                document.getElementById("send").innerHTML = "Your message has been received";
            }
