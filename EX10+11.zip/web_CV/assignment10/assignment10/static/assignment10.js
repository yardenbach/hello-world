function insert_massage(){
    document.getElementById("insert_massage").innerHTML = "the user inserted to the website";
}

function delete_massage(){
    document.getElementById("delete_massage").innerHTML = "the user deleted from the website";
}

function update_massage(){
    document.getElementById("update_massage").innerHTML = "the user updated in the website";
}