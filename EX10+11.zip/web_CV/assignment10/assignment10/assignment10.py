import mysql.connector
from flask import Blueprint, render_template, redirect
from flask import request, jsonify, session


assignment10 = Blueprint('assignment10', __name__, static_folder='static', static_url_path='/assignment10',
                         template_folder='templates')


def interact_db(query, query_type: str):
    return_value = False
    connection = mysql.connector.connect(host='localhost', user='root', passwd='root',
                                         database='users')
    cursor = connection.cursor(named_tuple=True)
    cursor.execute(query)
    if query_type == 'commit':
        connection.commit()
        return_value = True
    if query_type == 'fetch':
        query_result = cursor.fetchall()
        return_value = query_result

    connection.close()
    cursor.close()
    return return_value


@assignment10.route('/assignment10', methods=['GET', 'POST'])
def assignment10_2():
    query = "select * from users"
    query_result = interact_db(query, 'fetch')
    return render_template('assignment10.html', users=query_result)


@assignment10.route('/insertion', methods=['GET', 'POST'])
def insertion():
    if request.method == 'POST':
        name = request.form['name']
        last_name = request.form['last_name']
        email = request.form['email']
        query = "INSERT INTO users(name, last_name, email) VALUES('%s', '%s', '%s');" % (name, last_name, email)
        interact_db(query, 'commit')
        #session.pop('massage') ####################################
        #session["massage"] = 'the user inserted to the website' ####################
    return redirect('/assignment10')


@assignment10.route('/deletion', methods=['GET', 'POST'])
def deletion():
    if request.method == 'GET':
        if request.args:
            email2 = request.args['email2']
            query = "DELETE FROM users WHERE email= '%s';" % email2
            interact_db(query, 'commit')
            #session.pop('massage') ##############################################
    return redirect('/assignment10')
#


@assignment10.route('/update', methods=['GET', 'POST'])
def update():
    if request.method == 'GET':
        if request.args:
            up_email = request.args['up_email']
            name3 = request.args['name3']
            last_name3 = request.args['last_name3']
            email3 = request.args['email3']
            if name3 == '':
                query = "select name from users where email = '%s' ;" % up_email
                name3 = interact_db(query, 'fetch')[0].name
                print(name3)
            if last_name3 == '':
                query = "select last_name from users where email = '%s' ;" % up_email
                last_name3 = interact_db(query, 'fetch')[0].last_name
                print(last_name3)
            if email3 == '':
                email3 = up_email
            query = "UPDATE users SET name= '%s', last_name= '%s', email= '%s' WHERE email = '%s';" % (name3,
                                                                                                       last_name3,
                                                                                                       email3,
                                                                                                       up_email)
            interact_db(query, 'commit')

    return redirect('/assignment10')


@assignment10.route('/assignment11/users')
def assignment11():
    if request.method == 'GET':
        query = "select * from users"
        user_table = interact_db(query, 'fetch')
        ans_users = []
        for user in user_table:
            temp = {"id": user.id, "name": user.name, "last_name": user.last_name, "email": user.email}
            ans_users.append(temp)
    return jsonify(ans_users)


@assignment10.route('/assignment11/users/selected', defaults={'some_user_id': 1})
@assignment10.route('/assignment11/users/selected/<int:some_user_id>')  # ID=email try '1'
def fun_for_ass11(some_user_id=None):
    if some_user_id:
        query = "select * from users where id = '%s';" % some_user_id
        selected_user = interact_db(query, 'fetch')  # print result and type
        if selected_user:  # if not work try /// selected_user.name// or// selected_user.name != ''
            return jsonify(selected_user)
        else:
            return jsonify({"error": True, "error_code": 123, "error_massage": "we didnt find a user with this id"})
    else:
        return jsonify({"default_user": some_user_id})
