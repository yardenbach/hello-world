from flask import Flask, render_template, redirect, url_for
from flask import request, session
from assignment10.assignment10.assignment10 import assignment10


app = Flask(__name__)
app.secret_key = '12345'
app.register_blueprint(assignment10)


@app.route('/')
def foo():
    return render_template('summery_ex.html')


@app.route('/user_list')
def user_list():
    return render_template('user_list.html')


@app.route('/assignment8')
def assignment8():
    my_hobbies = ['Travel', 'Music', 'Friends']
    name = "Yarden"
    return render_template('assignment8.html', my_hobbies=my_hobbies, name=name)


@app.route('/assignment8/extend_of_assignment8')
def extend_of_assignment8():
    my_hobbies = ['Travel', 'Music', 'Friends']
    name = "Yarden"
    return render_template('extend_of_assignment8.html', my_hobbies=my_hobbies, name=name)


@app.route('/assignment9', methods=['GET', 'POST'])
def assignment9():
    searched_first, searched_last, searched_email = None, None, None
    reg_nickname, reg_password = None, None
    method = request.method
    users = [{"email": "yardenbach@gmail.com", "first_name": "Yarden", "last_name": "Bachar"},
             {"email": "lindsay.ferguson@reqres.in", "first_name": "Lindsay", "last_name": "Ferguson"},
             {"email": "tobias.funke@reqres.in", "first_name": "Tobias", "last_name": "Funke"},
             {"email": "byron.fields@reqres.in", "first_name": "Byron", "last_name": "Fields"}]
    if request.method == 'GET':
        if request.args:
            searched_first = request.args['first_name']
            searched_last = request.args['last_name']
            searched_email = request.args['email']
    if request.method == 'POST':
        reg_nickname = request.form['nickname']
        reg_password = request.form['password']
        session["logged_in"] = True
        session["nickname"] = reg_nickname
    return render_template('assignment9.html', users=users, searched_first=searched_first, searched_last=searched_last,
                           searched_email=searched_email, reg_nickname=reg_nickname, reg_passwoard=reg_password,
                           method=method)


@app.route('/log_out')
def log_out():
    session.pop('nickname')
    session['logged_in'] = False
    return redirect('/assignment9')


if (__name__) == '__main__':
    app.run(debug=True)
