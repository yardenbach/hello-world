from flask import Flask, redirect, url_for, render_template, request, flash
from flask import request

app = Flask(__name__)


@app.route('/')
def foo():
    return render_template('summery_ex.html')


@app.route('/user_list')
def user_list():
    return render_template('user_list.html')


@app.route('/assignment8')
def assignment8():
    my_hobbies = ['Travel', 'Music', 'Friends']
    name = "Yarden"
    return render_template('assignment8.html', my_hobbies=my_hobbies, name=name)


@app.route('/assignment8/extend_of_assignment8')
def extend_of_assignment8():
    my_hobbies = ['Travel', 'Music', 'Friends']
    name = "Yarden"
    return render_template('extend_of_assignment8.html', my_hobbies=my_hobbies, name=name)

if(__name__) == '__main__':
    app.run(debug=True)